<?php 
include "Components/navbar.php";
include "Components/sidebar.php";
include "Components/footer.php";